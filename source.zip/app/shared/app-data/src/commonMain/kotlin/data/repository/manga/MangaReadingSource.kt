// SPDX-License-Identifier: AGPL-3.0-only
package me.him188.ani.app.data.repository.manga
import com.fleeksoft.ksoup.Ksoup
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** Shared chapter and page parsing; the host supplies its network transport. */
class MangaReadingSource(private val fetchText: suspend (String) -> String, private val komiic: suspend (String, JsonObject) -> JsonObject) {
    private val additional = AdditionalMangaSources(fetchText)
    private val verified = VerifiedMangaSources(fetchText)
    suspend fun chapters(book: MangaSourceBook): List<MangaChapter> = when (book.source) {
        MangaSource.KOMIIC -> komiic(
            "Chapters",
            buildJsonObject { put("comicId", book.id) },
        ).array("chaptersByComicId").map {
            val c = it.jsonObject
            val group = if (c.text("type") == "book") "单行本" else "章节"
            MangaChapter(c.text("id"), "第 ${c.text("serial")} ${if (group == "单行本") "卷" else "话"}",
                c.text("serial").toDoubleOrNull(), group, c.number("size"))
        }.distinctBy { it.id }.sortedWith(compareBy<MangaChapter> { it.group == "单行本" }.thenBy { it.number ?: Double.MAX_VALUE })
        MangaSource.MANHUAGUI -> {
            var html = fetchText("${book.source.home}/comic/${book.id}/")
            Regex("""id="__VIEWSTATE"[^>]*value="([^"]+)""", RegexOption.IGNORE_CASE).find(html)?.let {
                html += ManhuaguiDecoder.decompress(it.groupValues[1])
            }
            parseChapters(book.id, html).also { check(it.isNotEmpty()) { "漫画柜未返回章节，可能需要验证或页面格式有变" } }
        }
        MangaSource.CCC, MangaSource.COMICK -> verified.chapters(book)
        else -> additional.chapters(book)
    }

    suspend fun pages(book: MangaSourceBook, chapter: MangaChapter): List<MangaPage> = when (book.source) {
        MangaSource.KOMIIC -> komiic(
            "Images",
            buildJsonObject { put("comicId", book.id); put("chapterId", chapter.id) },
        ).array("imagesByChapterId").map {
            val p = it.jsonObject
            val url = migrateMangaApiImageUrl(p.text("url"))
            check(url.startsWith("$KOMIIC_API_BASE_URL/images/")) { "Komiic 未返回有效的图片地址" }
            MangaPage(url, "$KOMIIC_API_BASE_URL/", p.number("width"), p.number("height"))
        }
        MangaSource.MANHUAGUI -> {
            val data = ManhuaguiDecoder.chapter(fetchText("${book.source.home}/comic/${book.id}/${chapter.id}.html"))
            data.array("files").map {
                MangaPage("https://us.hamreus.com${data.text("path")}${it.jsonPrimitive.content}?e=${data.obj("sl").text("e")}&m=${data.obj("sl").text("m")}",
                    "${book.source.home}/")
            }
        }
        MangaSource.CCC, MangaSource.COMICK -> verified.pages(book, chapter)
        else -> additional.pages(book, chapter)
    }.also { check(it.isNotEmpty()) { "该章节没有返回图片" } }


    companion object {
        internal fun parseChapters(bookId: String, html: String): List<MangaChapter> =
            Ksoup.parse(html).select("a[href]").mapNotNull { link ->
                val id = Regex("/comic/${Regex.escape(bookId)}/(\\d+)\\.html").matchEntire(link.attr("href"))
                    ?.groupValues?.get(1) ?: return@mapNotNull null
                if (link.text().contains("开始阅读")) return@mapNotNull null
                val name = link.attr("title").ifBlank { link.text().replace(Regex("\\s*\\d+\\s*p$"), "") }.trim()
                if (name.isBlank()) return@mapNotNull null
                val number = Regex("\\d+(?:\\.\\d+)?").find(name)?.value?.toDoubleOrNull()
                val group = when {
                    name.contains("卷") -> "单行本"
                    name.contains("番外") -> "番外"
                    Regex("^第?\\s*\\d").containsMatchIn(name) -> "章节"
                    else -> "其他"
                }
                val count = link.selectFirst("i")?.text()?.removeSuffix("p")?.trim()?.toIntOrNull() ?: 0
                MangaChapter(id, name, number, group, count)
            }.distinctBy { it.id }.sortedWith(compareBy<MangaChapter> { it.group != "章节" }
                .thenBy { it.group }.thenBy { it.number ?: Double.MAX_VALUE })
    }
}
