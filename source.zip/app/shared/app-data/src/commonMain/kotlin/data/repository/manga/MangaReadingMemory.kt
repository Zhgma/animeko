// SPDX-License-Identifier: AGPL-3.0-only
package me.him188.ani.app.data.repository.manga
import kotlinx.serialization.Serializable

@Serializable
data class MangaReadingMemory(
    val book: MangaSourceBook, val chapterId: String? = null, val page: Int = 0,
    val rightToLeft: Boolean = true, val firstPageSingle: Boolean = false,
    val sourcePinned: Boolean = true,
)

