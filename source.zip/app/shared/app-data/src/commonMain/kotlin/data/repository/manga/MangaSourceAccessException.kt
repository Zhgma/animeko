// SPDX-License-Identifier: AGPL-3.0-only
package me.him188.ani.app.data.repository.manga

class MangaSourceAccessException(message: String, val retryAfterMillis: Long? = null) : IllegalStateException(message)
