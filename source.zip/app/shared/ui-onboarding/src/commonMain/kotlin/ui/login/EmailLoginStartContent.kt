/*
 * Copyright (C) 2024-2026 OpenAni and contributors.
 *
 * 此源代码的使用受 GNU AFFERO GENERAL PUBLIC LICENSE version 3 许可证的约束, 可以在以下链接找到该许可证.
 * Use of this source code is governed by the GNU AGPLv3 license, which can be found at the following link.
 *
 * https://github.com/open-ani/ani/blob/main/LICENSE
 */

package me.him188.ani.app.ui.login

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import me.him188.ani.app.domain.session.auth.OAuthPlatform
import me.him188.ani.app.ui.lang.*
import org.jetbrains.compose.resources.*

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
internal fun EmailLoginStartScreenImpl(
    email: String,
    onContinueClick: (currentEmail: String) -> Unit,
    onThirdPartyLoginClick: (OAuthPlatform) -> Unit,
    onNavigateSettings: () -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier,
    title: @Composable () -> Unit = { Text(stringResource(Lang.login_sign_in)) },
    enabled: Boolean = true,
    thirdPartyPlatforms: List<OAuthPlatform> = emptyList(),
) {
    EmailLoginScreenLayout(
        onThirdPartyLoginClick,
        onNavigateSettings,
        onNavigateBack,
        modifier,
        title,
        thirdPartyPlatforms,
    ) { scrollState ->
        CenteredSectionHeader(
            title = { Text(stringResource(Lang.login_email_address_title)) },
            description = { Text(stringResource(Lang.login_email_address_description)) },
        )

        Spacer(Modifier.height(8.dp))

        var currentEmailContent by rememberSaveable { mutableStateOf(email) }
        OutlinedTextField(
            currentEmailContent,
            { currentEmailContent = it.trim() },
            Modifier.fillMaxWidth(),
            label = {
                Text(stringResource(Lang.login_email_label))
            },
            isError = currentEmailContent.isNotEmpty() &&
                    (!currentEmailContent.contains('@') || !currentEmailContent.contains('.')),
            singleLine = true,
            keyboardOptions = KeyboardOptions.Default.copy(
                autoCorrectEnabled = false,
                keyboardType = KeyboardType.Email,
                imeAction = ImeAction.Go,
            ),
            keyboardActions = KeyboardActions {
                onContinueClick(currentEmailContent)
            },
            trailingIcon = if (currentEmailContent.isNotEmpty()) {
                {
                    IconButton({ currentEmailContent = "" }) {
                        Icon(Icons.Outlined.Close, stringResource(Lang.login_clear))
                    }
                }
            } else null,
            enabled = enabled,
        )

        Spacer(Modifier.height(16.dp))

        Button(
            { onContinueClick(currentEmailContent) },
            Modifier.align(Alignment.End),
            contentPadding = ButtonDefaults.ButtonWithIconContentPadding,
            enabled = enabled,
        ) {
            Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, Modifier.size(ButtonDefaults.IconSize))
            Spacer(Modifier.width(ButtonDefaults.IconSpacing))
            Text(stringResource(Lang.login_continue))
        }
    }
}

