// SPDX-License-Identifier: AGPL-3.0-only
package me.him188.ani.app.ui.mediaselect.selector
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun WebSourceCardContent(name: String, icon: @Composable () -> Unit,
    channels: @Composable FlowRowScope.() -> Unit, trailing: @Composable () -> Unit = {}, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(Modifier.heightIn(min=48.dp),verticalAlignment=Alignment.CenterVertically) {
            icon()
            Box(Modifier.padding(start=8.dp)) {
                Text(name,Modifier.alpha(0f).width(IntrinsicSize.Max),softWrap=true,maxLines=2)
                Text(name,Modifier.matchParentSize(),softWrap=true,maxLines=2,overflow=TextOverflow.Clip)
            }
        }
        FlowRow(Modifier.weight(1f),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy((-8).dp),content=channels)
        trailing()
    }
}
