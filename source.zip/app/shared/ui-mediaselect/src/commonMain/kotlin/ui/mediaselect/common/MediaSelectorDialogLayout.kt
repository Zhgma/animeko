// SPDX-License-Identifier: AGPL-3.0-only
package me.him188.ani.app.ui.mediaselect.common
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.min
import me.him188.ani.app.ui.mediaselect.MediaSelectorLayoutDefaults
@Composable
fun MediaSelectorDialogLayout(
    onDismissRequest: () -> Unit,
    windowInsets: WindowInsets,
    modifier: Modifier = Modifier,
    content: @Composable (compact: Boolean) -> Unit,
) {
    val scrimColor = DrawerDefaults.scrimColor
    BoxWithConstraints(modifier.fillMaxSize()) {
        Canvas(
            Modifier.fillMaxSize().clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismissRequest,
            ),
        ) {
            drawRect(color = scrimColor)
        }
        val interceptClicks = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = {},
        )
        val compact = maxHeight < MediaSelectorLayoutDefaults.CompactDialogMaxHeight
        if (compact) {
            Surface(
                Modifier.fillMaxSize().then(interceptClicks).testTag(MediaSelectorDialogTestTags.SURFACE),
                shape = RectangleShape,
                color = BottomSheetDefaults.ContainerColor,
            ) {
                Box(Modifier.fillMaxSize().windowInsetsPadding(windowInsets)) {
                    content(true)
                }
            }
        } else {
            val width = min(MediaSelectorLayoutDefaults.DialogMaxWidth, maxWidth - MediaSelectorLayoutDefaults.DialogMargin)
            val height = min(MediaSelectorLayoutDefaults.DialogMaxHeight, maxHeight - MediaSelectorLayoutDefaults.DialogMargin)
            Surface(
                Modifier.align(Alignment.Center).size(width, height).then(interceptClicks)
                    .testTag(MediaSelectorDialogTestTags.SURFACE),
                shape = MaterialTheme.shapes.extraLarge,
                color = BottomSheetDefaults.ContainerColor,
            ) {
                content(false)
            }
        }
    }
}

