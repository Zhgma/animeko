/*
 * Copyright (C) 2024-2025 OpenAni and contributors.
 *
 * 此源代码的使用受 GNU AFFERO GENERAL PUBLIC LICENSE version 3 许可证的约束, 可以在以下链接找到该许可证.
 * Use of this source code is governed by the GNU AGPLv3 license, which can be found at the following link.
 *
 * https://github.com/open-ani/ani/blob/main/LICENSE
 */

package me.him188.ani.app.ui.subject

import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import kotlinx.datetime.TimeZone
import kotlinx.datetime.daysUntil
import kotlinx.datetime.toLocalDateTime
import me.him188.ani.app.data.models.subject.ContinueWatchingStatus
import me.him188.ani.app.data.models.subject.SubjectProgressInfo
import me.him188.ani.app.tools.WeekFormatter
import me.him188.ani.app.ui.foundation.stateOf
import me.him188.ani.datasources.api.toLocalDateOrNull
import kotlin.time.Clock
import kotlin.time.Instant

/**
 * 条目的观看进度, 用于例如 "看到 12" 的按钮
 */
@Stable // Test: AiringProgressTests
class SubjectProgressState(
    info: State<SubjectProgressInfo?>,
    private val weekFormatter: WeekFormatter = WeekFormatter.System,
) {
    /**
     * 从不可变的值构造. 值变化时由调用方重新构造 (例如 `remember(info) { ... }`).
     */
    constructor(
        info: SubjectProgressInfo?,
        weekFormatter: WeekFormatter = WeekFormatter.System,
    ) : this(stateOf(info), weekFormatter)

    private val continueWatchingStatus by derivedStateOf {
        info.value?.continueWatchingStatus
    }

    /**
     * 是否拥有至少一话, 并且已经观看了这一话, 并且没有更新的了.
     */
    val isLatestEpisodeWatched by derivedStateOf {
        continueWatchingStatus is ContinueWatchingStatus.Watched
    }

    /**
     * 已经完结并且看完了
     */
    val isDone by derivedStateOf {
        continueWatchingStatus == ContinueWatchingStatus.Done
    }

    val episodeIdToPlay: Int? by derivedStateOf {
        info.value?.nextEpisodeIdToPlay
    }

    fun buttonText(
        strings: SubjectStatusStrings,
        now: Instant = Clock.System.now(),
        timeZone: TimeZone = TimeZone.currentSystemDefault(),
    ): String {
        return when (val s = continueWatchingStatus) {
            is ContinueWatchingStatus.Continue -> strings.continueWatching(renderEpAndSort(s.episodeEp, s.episodeSort))
            ContinueWatchingStatus.Done -> strings.done
            is ContinueWatchingStatus.NotOnAir -> {
                val date = s.airDate.toLocalDateOrNull()
                if (date != null) {
                    val week = weekFormatter.format(date, timeZone)
                    strings.startsOn(week)
                } else {
                    strings.notOnAir
                }
            }

            ContinueWatchingStatus.Start -> strings.startWatching
            is ContinueWatchingStatus.Watched -> {
                s.nextEpisodeAirTime?.let { time ->
                    val localTime = time.toLocalDateTime(timeZone)
                    val daysAhead = now.toLocalDateTime(timeZone).date.daysUntil(localTime.date)
                    if (daysAhead == 0 || (daysAhead == 1 && localTime.hour < 6)) {
                        val hour = localTime.hour + daysAhead * 24
                        return "${hour.toString().padStart(2, '0')}:${localTime.minute.toString().padStart(2, '0')}"
                    }
                }
                val date = s.nextEpisodeAirDate.toLocalDateOrNull()
                if (date != null) {
                    val week = weekFormatter.format(date, timeZone)
                    strings.updatesOn(week)
                } else {
                    strings.watched(renderEpAndSort(s.episodeEp, s.episodeSort))
                }
            }

            null -> strings.unknown
        }
    }

    val buttonIsPrimary by derivedStateOf {
        when (continueWatchingStatus) {
            is ContinueWatchingStatus.Start,
            is ContinueWatchingStatus.Continue -> true

            else -> false
        }
    }
}
