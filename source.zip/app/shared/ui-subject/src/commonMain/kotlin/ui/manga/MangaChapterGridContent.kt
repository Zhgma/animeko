// SPDX-License-Identifier: AGPL-3.0-only
package me.him188.ani.app.ui.manga
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import me.him188.ani.app.data.repository.manga.*
import me.him188.ani.app.ui.subject.details.sections.PagedEpisodesGrid
import me.him188.ani.app.ui.subject.details.sections.SectionHeader
import me.him188.ani.app.ui.subject.episode.list.EpisodeListItem
import me.him188.ani.datasources.api.EpisodeSort
import me.him188.ani.datasources.api.topic.UnifiedCollectionType

@Composable
internal fun MangaChapterGridContent(subjectId: Int, book: MangaSourceBook?, catalog: List<MangaChapter>,
    anchor: MangaChapter?, memory: MangaReadingMemory?, readChapters: Int?, readVolumes: Int?,
    onChapter: (MangaChapter) -> Unit, onMarkRead: (MangaChapter) -> Unit,
    onSources: () -> Unit, onCache: (() -> Unit)? = null, rows: Int = 2) {
    var group by rememberSaveable(subjectId, book?.source, book?.id, anchor?.group) { mutableStateOf("") }
    var descending by rememberSaveable(subjectId, book?.source, book?.id) { mutableStateOf(true) }
    val selected = group.takeIf { g -> catalog.any { it.group == g } } ?: anchor?.group ?: catalog.firstOrNull()?.group
    val chapters = catalog.filter { it.group == selected }.let { if (descending) it.reversed() else it }
    var actionChapter by remember { mutableStateOf<MangaChapter?>(null) }
    val items = chapters.mapIndexed { index, chapter ->
        val count = if (chapter.group == "单行本") readVolumes else readChapters
        EpisodeListItem(index, EpisodeSort(chapter.number?.toString().orEmpty()), null, chapter.title, chapter.title,
            if (count != null && chapter.number?.let { it <= count } == true) UnifiedCollectionType.DONE else UnifiedCollectionType.NOT_COLLECTED,
            true, playProgress = if (chapter.id == memory?.chapterId && chapter.pageCount > 0)
                (memory.page + 1).toFloat() / chapter.pageCount else null)
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            catalog.map { it.group }.distinct().forEach { name -> FilterChip(selected == name, { group = name }, label = { Text(name) }) }
            TextButton({ descending = !descending }, Modifier.testTag("manga-chapter-sort")) {
                Text(if (descending) "倒序" else "正序")
            }
        }
        key(subjectId, book?.source, book?.id, selected, descending) {
            PagedEpisodesGrid(items, chapters.indexOfFirst { it.id == anchor?.id }.takeIf { it >= 0 },
                { onChapter(chapters[it.episodeId]) }, { actionChapter = chapters[it.episodeId] }, rowsPerPage = rows, showImages = false,
                header = { pager -> SectionHeader("章节") {
                    pager?.invoke()
                    if (onCache != null) TextButton(onCache, Modifier.testTag("manga-cache-open")) { Text("缓存") }
                    TextButton(onSources) { Text("数据源") }
                } })
        }
    }
    actionChapter?.let { chapter ->
        AlertDialog(onDismissRequest = { actionChapter = null }, title = { Text(chapter.title) },
            text = { Text(if (onCache != null) "更新 Bangumi 阅读进度或管理离线缓存" else "更新 Bangumi 阅读进度") },
            confirmButton = { TextButton({ onMarkRead(chapter); actionChapter = null }, enabled = readChapters != null && chapter.group in listOf("章节", "单行本") && chapter.number?.let { it.isFinite() && it >= 1 && it % 1.0 == 0.0 } == true) { Text("标记读过") } },
            dismissButton = { if (onCache != null) TextButton({ actionChapter = null; onCache() }) { Text("缓存") } else TextButton({ actionChapter = null }) { Text("取消") } })
    }
}

