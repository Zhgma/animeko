// SPDX-License-Identifier: AGPL-3.0-only
package me.him188.ani.app.ui.manga
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.unit.dp

@Composable
internal fun MangaInlineError(message: String, onRetry: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(message, color = MaterialTheme.colorScheme.error)
        OutlinedButton(onRetry) { Text("重试") }
    }
}
