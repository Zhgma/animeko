/*
 * Copyright (C) 2024-2025 OpenAni and contributors.
 *
 * 此源代码的使用受 GNU AFFERO GENERAL PUBLIC LICENSE version 3 许可证的约束, 可以在以下链接找到该许可证.
 * Use of this source code is governed by the GNU AGPLv3 license, which can be found at the following link.
 *
 * https://github.com/open-ani/ani/blob/main/LICENSE
 */

package me.him188.ani.app.ui.exploration.schedule

import me.him188.ani.app.domain.episode.AiringScheduleDateRange

import androidx.compose.runtime.Immutable
import kotlinx.datetime.DatePeriod
import kotlinx.datetime.DayOfWeek
import kotlinx.datetime.LocalDate
import kotlinx.datetime.LocalTime
import kotlinx.datetime.minus
import kotlinx.datetime.plus
import me.him188.ani.datasources.api.EpisodeSort
import me.him188.ani.datasources.api.topic.UnifiedCollectionType
import me.him188.ani.utils.platform.annotations.TestOnly

@Immutable
data class AiringScheduleItemPresentation(
    val subjectId: Int,
    val subjectTitle: String,
    /** 条目原名 (通常为日文), 供"显示原名"设置开启时使用; 关闭时忽略, 显示 [subjectTitle]. */
    val subjectOriginalTitle: String = subjectTitle,
    val imageUrl: String,
    val episodeId: Int,
    val episodeSort: EpisodeSort,
    val episodeEp: EpisodeSort?,
    val episodeName: String?,
    /** 剧集原名, 同 [subjectOriginalTitle] 的开关约定. */
    val episodeOriginalName: String? = episodeName,

    val subjectCollectionType: UnifiedCollectionType,
    val dayOfWeek: DayOfWeek,
    /**
     * 放送时刻. `null` 表示时间未定 (只知道放送日期), 界面显示 "时间未定", 并排在当天所有已知时间的项目之后.
     */
    val time: LocalTime?,
)

@Immutable
data class AiringSchedule(
    val date: LocalDate,
    val episodes: List<AiringScheduleColumnItem>,
)

@Immutable
data class ScheduleDay(
    val date: LocalDate,
    val kind: Kind,
) {
    val dayOfWeek: DayOfWeek get() = date.dayOfWeek

    enum class Kind {
        LAST_WEEK,
        TODAY,
        THIS_WEEK,
        NEXT_WEEK,
    }

    companion object {
        fun generateForRecentTwoWeeks(
            today: LocalDate,
        ): List<ScheduleDay> {
            // 假设今天是本周三, 返回的是上周三到下周三
            return SchedulePageDataHelper.OFFSET_DAYS_RANGE.map { offsetDays ->
                val date = today.plus(DatePeriod(days = offsetDays))
                val thisWeekRange: ClosedRange<LocalDate> = getWeekRange(today)
                ScheduleDay(
                    date = date,
                    kind = when {
                        date == today -> Kind.TODAY
                        date in thisWeekRange -> Kind.THIS_WEEK
                        date > thisWeekRange.endInclusive -> Kind.NEXT_WEEK
                        date < thisWeekRange.start -> Kind.LAST_WEEK
                        else -> error("unreachable")
                    },
                )
            }
        }

        private fun getWeekRange(date: LocalDate): ClosedRange<LocalDate> {
            val dayOfWeek = date.dayOfWeek
            return date.minus(DatePeriod(days = dayOfWeek.ordinal))..date.plus(DatePeriod(days = 6 - dayOfWeek.ordinal))
        }
    }
}

object SchedulePageDataHelper {
    val OFFSET_DAYS_RANGE = AiringScheduleDateRange.OFFSETS

    /**
     * 把一天的项目转换为列表项:
     * - 已知时间的项目按时间升序 (稳定排序, 同一时间保持输入顺序), 只有与上一项时间不同的项目显示时间;
     * - [addIndicator] 时, 在最后一个 `time <= currentTime` 的项目之后插入当前时间指示器;
     * - 时间未定 (`time == null`) 的项目保持输入顺序, 追加在所有已知时间的项目和指示器之后, 只有第一个显示 "时间未定".
     */
    fun toColumnItems(
        list: List<AiringScheduleItemPresentation>,
        addIndicator: Boolean,
        currentTime: LocalTime,
    ): List<AiringScheduleColumnItem> {
        val (timed, timeUnknown) = list.partition { it.time != null }
        val sortedTimed = timed.sortedBy { it.time }
        val insertionIndex = sortedTimed.indexOfLast { checkNotNull(it.time) <= currentTime }
        return buildList(capacity = list.size + 1) {
            var previousTime: LocalTime? = null
            val handleItem = { itemPresentation: AiringScheduleItemPresentation ->
                val showtime = previousTime != itemPresentation.time
                previousTime = itemPresentation.time
                add(
                    AiringScheduleColumnItem.Data(
                        item = itemPresentation,
                        showtime,
                    ),
                )
            }

            for (itemPresentation in sortedTimed.subList(0, insertionIndex + 1)) {
                handleItem(itemPresentation)
            }
            if (addIndicator) {
                add(
                    AiringScheduleColumnItem.CurrentTimeIndicator(
                        currentTime = currentTime,
                        isPlaceholder = false,
                    ),
                )
            }
            for (itemPresentation in sortedTimed.subList(insertionIndex + 1, sortedTimed.size)) {
                handleItem(itemPresentation)
            }
            timeUnknown.forEachIndexed { index, itemPresentation ->
                add(
                    AiringScheduleColumnItem.Data(
                        item = itemPresentation,
                        showTime = index == 0,
                    ),
                )
            }
        }
    }
}