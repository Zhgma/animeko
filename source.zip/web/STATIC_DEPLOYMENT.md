# 静态网页与远程 API 部署验收

## 架构

浏览器加载静态 HTML、JavaScript、Wasm、字体和图片资源。业务 API 使用 `https://119.28.149.19:8443/api/web`，由 SSH 主机 `winserver` 访问 Animeko、Bangumi、订阅和网站。用户电脑无需 Node/API 进程。漫画继续编译 App 的 `MangaRequestRouting`，使用现有书籍 API；Komiic 原有服务保持独立。

`api-endpoints.js` 声明远程入口。App 生成的 Animeko 客户端使用 `/animeko` 前缀，保留请求模型；浏览器 OAuth/邮箱适配使用 `/auth/animeko`。全部路由、鉴权、来源策略和部署方法见 [Web API 契约](../services/web-api/README.md)。

## 静态构建

使用 JDK 21，在 `web/` 执行 `../gradlew.bat :wasmJsBrowserDevelopmentExecutableDistribution` 或优化发布任务 `:wasmJsBrowserDistribution`。上传对应 `build/dist/wasmJs/developmentExecutable` 或 `productionExecutable` 的内容。资源 URL 为相对路径，导航使用 hash，可在 GitHub Pages 仓库子路径运行。静态服务器需支持 Wasm MIME。

本地 `serve.mjs` 只提供静态文件和 `/api/health` 启动诊断。生产静态站无需实现任何 `/api/*`。API CORS 已精确允许 `https://zhgma.github.io`；自定义 Pages 域名需要添加到服务允许列表。

## 2026-10-12 本次部署证据

- 新服务部署在 `C:\ProgramData\AnimeComicWebApi\releases\20261012-web-api-v1`，计划任务 `AnimeComic-WebApi` 开机启动、失败重启，只监听远端 `127.0.0.1:4182`；现有 Caddy 和 IP TLS 证书提供公网入口。
- 公网正常验证证书，以 GitHub Pages Origin 请求：健康、登录方式、公开番剧详情、热榜、剧集、评论、默认网站订阅、AnimeGarden RSS 均 HTTP 200，允许 origin 精确匹配。PATCH 预检 204；无凭据写入 401；未许可 origin 403。
- Bangumi/GitHub OAuth 开始请求均 200，返回对应正确授权站点；随后轮询均 425 等待。未在第三方完成授权，未发送真实邮件、未上传用户令牌、未改收藏。
- 原有书籍详情和 Komiic 健康均 200。
- 92 项 Node 回归通过，包含网关 6 项；远端部署前重复通过网关测试。23 项 Kotlin/Wasm 浏览器测试通过，静态开发分发构建成功。
- 真实浏览器从只提供文件的 `http://127.0.0.1:4180/animeko/` 加载 Compose 网页。探索内容、详情封面和播放第 1 话入口正常；账号显示邮箱页面和 Bangumi/GitHub 登录按钮。
- 独立浏览器只读验收：登录方式 `bangumi, github`；番剧 622288 共 14 个剧集记录；默认订阅 18 个来源；RSS 成功；网站搜索返回 41679 字符。请求目标均为远程 API，纯文件服务器本身没有这些接口。
- 本机原 4173 进程保持运行。本次使用独立源码快照构建和 4180 文件服务验证，未覆盖主任务的构建产物。

证据保存在仓库外 `../artifacts/static-web-repair-20261012/`，包括 remote-node-tests.log、remote-build.log、remote-install.log、remote-browser-results.json、remote-oauth-probe.json 和截图。

## 明确未完成的范围

- GitHub Pages 尚未发布：当前 GitHub CLI 没有登录，仓库 Pages 配置与部署未完成；远程 API 上线不等于 Pages 网站上线。
- 真实邮箱登录、OAuth 完整授权、令牌刷新、收藏写入：传输契约已回归测试，本轮未对真实账号做写操作。
- 视频 CDN/HLS 分片仍由浏览器读取，站点嵌入、动态 JS 嗅探、验证码、DRM 和编码能力不会因 API 网关自动解决。本轮没有验证完整视频播放。
- 订阅可读取/导入；网站 HTML 执行限 App 默认网站订阅及其验证过的跳转来源。额外自定义网站需要扩展服务器来源策略。
- WebTorrent 仍是浏览器 WebRTC/Web Seed；网关可读取 .torrent 元数据，不运行普通 TCP/UDP BT 下载器。
- 完整原生 ViewModel、Room、播放和漫画阅读适配仍按 [功能差异清单](PARITY.md) 记录。API 部署不代表全部页面与 App 已完全对齐。
