// SPDX-License-Identifier: AGPL-3.0-only
import https from 'node:https';
import {lookup} from 'node:dns/promises';
import {createHash, createDecipheriv} from 'node:crypto';
import {publicAddress, isMangaSearchUrl} from './online-relay.mjs';

const pagePaths = {
  'www.manhuagui.com': /^\/comic\/\d+\/(?:\d+\.html)?$/,
  'www.manhuaren.com': /^\/(?:manhua-\d+|m\d+)\/$/,
  'm.ykmh.net': /^(?:\/manhua\/[\w-]+\/(?:\d+\.html)?|\/js\/config\.js)$/,
  'cn.bzmgcn.com': /^\/comic\/[\w-]+$/,
  'appcn.baozimh.com': /^\/baozimhapp\/comic\/chapter\/[\w-]+\/0_\d+\.html$/,
  'godamh.com': /^\/manga\/[\w-]+$/,
  'v2.apikk.top': /^\/api\/v2\/(?:manga\/get|chapter\/getinfo)$/,
  'api.creative-comic.tw': /^\/book\/(?:\d+\/chapter|chapter\/\d+|chapter\/image\/\d+)$/,
  'comick.art': /^\/(?:api\/comics\/[\w-]+\/chapter-list|comic\/[\w-]+\/[\w.-]+)(?:\/)?$/,
};
const sourceHomes = new Set(['www.manhuagui.com','www.manhuaren.com','www.ykmh.net','m.ykmh.net','cn.bzmgcn.com','godamh.com','www.creative-comic.tw','comick.art']);
const imageDomains = ['hamreus.com','manhuaren.com','mhpic.com','6wm.top','baozicdn.com','baozimh.com','ykmh.com','ykmh.net','comick.art','comick.io','comick.pictures'];
export function safeMangaUrl(value) {
  const u = new URL(value);
  if (u.protocol !== 'https:' || u.port || u.username || u.password || u.hash || u.href.length > 4096) throw new Error('漫画来源地址无效');
  return u;
}
export function isMangaPage(value) {
  try { const u = safeMangaUrl(value); return isMangaSearchUrl(u) || pagePaths[u.hostname]?.test(u.pathname) === true; } catch { return false; }
}
export function mangaImageRequest(value, referer, ccc) {
  const u = safeMangaUrl(value), ref = safeMangaUrl(referer);
  if (!sourceHomes.has(ref.hostname)) throw new Error('图片来源无效');
  if (ccc) {
    if (!/^[1-9]\d*$/.test(ccc) || u.href !== `https://storage.googleapis.com/ccc-www/fs/chapter_content/encrypt/${ccc}/2` || ref.hostname !== 'www.creative-comic.tw') throw new Error('CCC 图片地址无效');
  } else if (!imageDomains.some(d => u.hostname === d || u.hostname.endsWith('.' + d))) throw new Error('图片主机尚未适配，请切换来源');
  return {url:u.href, referer:ref.href, ccc};
}
/** Fixed source hosts, pinned public DNS, no cookies, no redirects, bounded image response. */
export async function readManga(url, referer, image = false) {
  const u = safeMangaUrl(url);
  const addresses = await lookup(u.hostname,{all:true,family:4});
  if (!addresses.length || addresses.some(a => !publicAddress(a.address))) throw new Error('不允许访问本地网络');
  return new Promise((resolve,reject) => {
    const req = https.get(u,{lookup:(_h,o,cb) => o.all ? cb(null,addresses) : cb(null,addresses[0].address,4),
      headers:{'User-Agent':'Mozilla/5.0',Accept:image?'image/*':'text/html,application/json,*/*',Referer:referer || u.origin+'/',
        ...(u.hostname==='api.creative-comic.tw'?{device:'web_desktop',uuid:'null',Referer:'https://www.creative-comic.tw/'}:{})}},res => {
      let size=0; const chunks=[];
      res.on('data',c=>{size+=c.length;if(size>(image?25_000_000:4_000_000))req.destroy(new Error('来源响应过大'));else chunks.push(c);});
      res.on('end',()=>resolve({status:res.statusCode,type:res.headers['content-type']||'',retryAfter:res.headers['retry-after'],bytes:Buffer.concat(chunks)}));
      res.on('error',reject);
    });
    const deadline=setTimeout(()=>req.destroy(new Error('漫画来源请求超时')),30000);
    req.on('close',()=>clearTimeout(deadline));req.on('error',reject);
  });
}
function decrypt(key,iv,bytes) { const d=createDecipheriv('aes-256-cbc',key,iv);return Buffer.concat([d.update(bytes),d.final()]); }
export function decodeCcc(key,payload) {
  const seed=createHash('sha512').update('freeforccc2020reading').digest();
  const values=decrypt(seed.subarray(0,32),seed.subarray(15,31),Buffer.from(key,'base64')).toString().split(':');
  if(values.length!==2||!/[a-f0-9]{64}/i.test(values[0])||!/[a-f0-9]{32}/i.test(values[1]))throw new Error('CCC 图片密钥格式有变');
  const text=decrypt(Buffer.from(values[0],'hex'),Buffer.from(values[1],'hex'),payload).toString();
  const bytes=Buffer.from(text.substring(text.indexOf(',')+1),'base64');
  if(!bytes.length||bytes.length>25_000_000)throw new Error('CCC 图片大小异常');return bytes;
}
export function createMangaRelay({read=readManga}={}) {
  return async(req,res,url)=>{
    if(!url.pathname.startsWith('/api/manga/'))return false;
    const json=(status,value)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value));};
    if(req.method!=='GET'){json(405,{error:'只允许读取'});return true;}
    try {
      const image=url.pathname==='/api/manga/image';
      if(!image&&url.pathname!=='/api/manga/page'){json(404,{error:'接口不存在'});return true;}
      const value=url.searchParams.get('url');
      let options;
      if(image)options=mangaImageRequest(value,url.searchParams.get('referer'),url.searchParams.get('ccc'));
      else {if(!isMangaPage(value)){json(403,{error:'漫画来源路径未获准'});return true;}options={url:value};}
      let key;
      if(options.ccc){
        const response=await read(`https://api.creative-comic.tw/book/chapter/image/${options.ccc}`);
        if(response.status!==200)throw new Error('CCC 图片密钥请求失败');
        const data=JSON.parse(response.bytes.toString());
        if(data.code!==0||!data.data?.key){json(403,{error:'该章节需要登录或购买，请到原站阅读'});return true;}key=data.data.key;
      }
      const response=await read(options.url,options.referer,image);
      if(response.status!==200){if(response.retryAfter)res.setHeader('Retry-After',response.retryAfter);json(response.status>=400&&response.status<=599?response.status:502,{error:`漫画来源返回 HTTP ${response.status}，请稍后重试或切换来源`});return true;}
      if(image){
        const bytes=key?decodeCcc(key,response.bytes):response.bytes;
        if(!key&&!/^image\//i.test(response.type))throw new Error('来源返回的不是图片');
        res.writeHead(200,{'Content-Type':key?'image/jpeg':response.type,'Content-Length':bytes.length,'Cache-Control':'private,max-age=3600'});res.end(bytes);
      } else {
        if(!/^(text\/|application\/(json|javascript))/i.test(response.type))throw new Error('来源没有返回网页或 JSON');
        json(200,{text:response.bytes.toString('utf8')});
      }
    }catch(e){json(502,{error:e.message||'漫画来源读取失败'});}return true;
  };
}
