// SPDX-License-Identifier: AGPL-3.0-only
@file:OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class, kotlin.js.ExperimentalWasmJsInterop::class)

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.HtmlElementView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import me.him188.ani.app.ui.mediaselect.manual.ManualEpisodeGrid
import me.him188.ani.app.ui.subject.episode.EpisodeScreenLayout
import me.him188.ani.app.ui.subject.episode.EpisodeScreenLayoutMode
import me.him188.ani.app.ui.subject.episode.video.topbar.EpisodePlayerTitle
import me.him188.ani.datasources.api.source.BrowseEpisode
import org.w3c.dom.HTMLElement

@JsFun("(json, callback) => window.aniCreateVideo(json, callback)")
private external fun createBrowserVideo(json: String, callback: (String) -> Unit): HTMLElement
@JsFun("(element, action, value) => element.aniCommand(action, value)")
private external fun videoCommand(element: HTMLElement, action: String, value: Double)
@JsFun("element => element.aniDispose()")
private external fun disposeVideo(element: HTMLElement)

@Serializable
private data class BrowserVideoState(
    val position: Int = 0, val time: Double = 0.0, val duration: Double = 0.0,
    val paused: Boolean = true, val muted: Boolean = false, val loading: Boolean = true,
    val message: String = "正在提取视频…", val failed: Boolean = false,
    val rate: Double = 1.0, val fullscreen: Boolean = false,
)

private fun videoTime(seconds: Double): String {
    val value = seconds.toInt().coerceAtLeast(0)
    return "${value / 60}:${(value % 60).toString().padStart(2, '0')}"
}

/** App layout and episode widgets; HTML video is only the platform playback surface. */
@Composable
fun WebPlayerScreen(payload: JsonObject, onClose: (JsonObject?) -> Unit) {
    val episodes = remember(payload) { payload["episodes"]?.jsonArray.orEmpty().map {
        BrowseEpisode(it.jsonObject["name"]!!.jsonPrimitive.content, it.jsonObject["url"]!!.jsonPrimitive.content)
    } }
    val title = payload["title"]?.jsonPrimitive?.content.orEmpty()
    val source = payload["sourceName"]?.jsonPrimitive?.content.orEmpty()
    val channel = payload["channel"]?.jsonPrimitive?.content.orEmpty()
    var state by remember { mutableStateOf(BrowserVideoState(position=payload["index"]?.jsonPrimitive?.intOrNull ?: 0)) }
    var element by remember { mutableStateOf<HTMLElement?>(null) }
    var sidebar by remember { mutableStateOf(true) }
    var speedMenu by remember { mutableStateOf(false) }
    var seeking by remember { mutableStateOf<Float?>(null) }
    fun command(action: String, value: Double = 0.0) { element?.let { videoCommand(it, action, value) } }
    val close = { onClose(payload["episodes"]?.jsonArray?.getOrNull(state.position)?.jsonObject) }
    Dialog(onDismissRequest=close, properties=DialogProperties(usePlatformDefaultWidth=false)) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val wide = maxWidth >= 840.dp || (maxWidth >= 600.dp && maxHeight < 480.dp)
            val mode = when {
                state.fullscreen || !sidebar -> EpisodeScreenLayoutMode.VIDEO_ONLY
                wide -> EpisodeScreenLayoutMode.WIDE
                else -> EpisodeScreenLayoutMode.COMPACT
            }
            Surface(Modifier.fillMaxSize()) {
                EpisodeScreenLayout(mode, video={
                    Column((if(mode==EpisodeScreenLayoutMode.COMPACT) Modifier.fillMaxWidth() else Modifier.fillMaxSize()).background(Color.Black)) {
                        CompositionLocalProvider(LocalContentColor provides Color.White) {
                            Row(Modifier.fillMaxWidth().height(64.dp).padding(end=8.dp), verticalAlignment=Alignment.CenterVertically) {
                                IconButton(close) { Icon(Icons.AutoMirrored.Rounded.ArrowBack,"返回选源") }
                                EpisodePlayerTitle((state.position+1).toString().padStart(2, '0'),episodes.getOrNull(state.position)?.name.orEmpty(),title,Modifier.weight(1f))
                                IconButton({sidebar=!sidebar}) { Icon(if(sidebar) Icons.Rounded.ChevronRight else Icons.Rounded.ChevronLeft,if(sidebar) "收起详情" else "展开详情") }
                            }
                            HtmlElementView(
                                factory={createBrowserVideo(payload.toString()) { state=webJson.decodeFromString<BrowserVideoState>(it) }.also { element=it }},
                                modifier=if(mode==EpisodeScreenLayoutMode.COMPACT) Modifier.fillMaxWidth().aspectRatio(16f/9f) else Modifier.fillMaxWidth().weight(1f),
                                onRelease={disposeVideo(it);element=null},
                            )
                            if(state.message.isNotBlank()) Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically) {
                                Text(state.message,Modifier.weight(1f),color=if(state.failed) MaterialTheme.colorScheme.error else Color.White,style=MaterialTheme.typography.bodySmall,maxLines=2,overflow=TextOverflow.Ellipsis)
                                if(state.failed) TextButton({command("retry")}) { Text("重试") }
                            }
                            Slider(value=seeking ?: state.time.toFloat(),onValueChange={seeking=it},
                                onValueChangeFinished={seeking?.let { command("seek",it.toDouble()) };seeking=null},
                                valueRange=0f..state.duration.toFloat().coerceAtLeast(1f),enabled=state.duration>0,
                                modifier=Modifier.fillMaxWidth().height(28.dp).padding(horizontal=16.dp).semantics { contentDescription="播放进度" })
                            Row(Modifier.fillMaxWidth().padding(horizontal=8.dp),verticalAlignment=Alignment.CenterVertically) {
                                IconButton({command("toggle")}) { Icon(if(state.paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,if(state.paused) "播放" else "暂停",Modifier.size(32.dp)) }
                                IconButton({command("episode",(state.position+1).toDouble())},enabled=state.position<episodes.lastIndex) { Icon(Icons.Rounded.SkipNext,"下一集") }
                                Text("${videoTime(state.time)} / ${videoTime(state.duration)}",style=MaterialTheme.typography.labelSmall,modifier=Modifier.weight(1f))
                                Box {
                                    TextButton({speedMenu=true}) { Text("${state.rate}×",color=Color.White) }
                                    if (speedMenu) DropdownMenu(true,{speedMenu=false}) {
                                        listOf(.5,.75,1.0,1.25,1.5,2.0).forEach { rate -> DropdownMenuItem(text={Text("${rate}×")},onClick={command("rate",rate);speedMenu=false}) }
                                    }
                                }
                                IconButton({command("mute")}) { Icon(if(state.muted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,"静音切换") }
                                IconButton({command("fullscreen")}) { Icon(if(state.fullscreen) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,if(state.fullscreen) "退出全屏" else "全屏") }
                            }
                        }
                    }
                },secondary={
                    Column(Modifier.fillMaxSize()) {
                        PrimaryTabRow(0) { Tab(true,{},text={Text("详情")}) }
                        Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                            Text(title,style=MaterialTheme.typography.titleLarge,maxLines=2,overflow=TextOverflow.Ellipsis)
                            Text(episodes.getOrNull(state.position)?.name.orEmpty(),style=MaterialTheme.typography.bodyMedium)
                            ListItem(headlineContent={Text("数据源")},supportingContent={Text(listOf(source,channel).filter { it.isNotBlank() }.joinToString(" · "),maxLines=2,overflow=TextOverflow.Ellipsis)},
                                trailingContent={TextButton(close){Text("切换")}})
                        }
                        ManualEpisodeGrid(episodes,state.position,{command("episode",it.toDouble())},null,{},if(wide) 3 else 4,Modifier.weight(1f),PaddingValues(16.dp))
                    }
                },modifier=Modifier.fillMaxSize())
            }
        }
    }
}
