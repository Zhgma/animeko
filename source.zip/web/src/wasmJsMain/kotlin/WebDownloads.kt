import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.serialization.json.*
import me.him188.ani.app.ui.adaptive.AniTopAppBar

@Composable fun WebDownloads() {
    val media = rememberBrowserMedia()
    var add by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }
    var removing by remember { mutableStateOf<TorrentTask?>(null) }
    Column(Modifier.fillMaxSize()) {
        AniTopAppBar(title = { Text("下载") }, actions = {
            TextButton({ add = true }) { Text("添加任务") }
            TextButton({ media.action("torrentFile") }, enabled = !media.busy) { Text("导入种子") }
        })
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("WebTorrent · 浏览器下载", style = MaterialTheme.typography.titleMedium)
                Text("连接 WebRTC 节点与 Web Seed。关闭网页后停止传输；重新打开可继续任务。普通 TCP/UDP 节点无法直连。", style = MaterialTheme.typography.bodyMedium)
                if (!media.state.secure || !media.state.webrtc) Text("需要 HTTPS（或 localhost）以及支持 WebRTC 的浏览器。", color = MaterialTheme.colorScheme.error)
                MediaStatus(media)
                if (media.state.tasks.isEmpty()) Text("暂无下载任务", Modifier.padding(vertical = 24.dp))
            }
            items(media.state.tasks, key = { it.id }) { task ->
                TorrentTaskCard(task, media) { removing = task }
            }
        }
    }
    if (add) AlertDialog(onDismissRequest = { if (!media.busy) add = false }, title = { Text("添加下载任务") }, text = {
        Column { OutlinedTextField(url, { url = it }, label = { Text("磁力链接、种子网址或 Info Hash") }, modifier = Modifier.fillMaxWidth()); MediaStatus(media) }
    }, confirmButton = { TextButton({ media.action("torrentAdd", buildJsonObject { put("url", url) }) { add = false; url = "" } }, enabled = url.isNotBlank() && !media.busy) { Text("添加") } }, dismissButton = { TextButton({ add = false }, enabled = !media.busy) { Text("取消") } })
    removing?.let { task -> AlertDialog(onDismissRequest = { removing = null }, title = { Text("移除下载任务？") }, text = { Text("${task.name}\n已保存到本机的文件不会删除。浏览器中停止任务留下的缓存由浏览器存储管理。") }, confirmButton = { TextButton({ media.action("torrentRemove", mediaId(task.id)) { removing = null } }, enabled = !media.busy) { Text("移除") } }, dismissButton = { TextButton({ removing = null }) { Text("取消") } }) }
}
@Composable fun MediaStatus(media: BrowserMediaController) {
    if (media.busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
    media.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp)) }
}
@Composable private fun TorrentTaskCard(task: TorrentTask, media: BrowserMediaController, onRemove: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val active = task.state in listOf("metadata", "downloading", "done")
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (task.subjectTitle.isNotBlank()) Text(task.subjectTitle + if (task.episode.isBlank()) "" else " · 第 ${task.episode} 话（手动选择）", style = MaterialTheme.typography.labelMedium)
        Text(task.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(when(task.state) { "metadata" -> "等待种子元数据"; "downloading" -> "下载中"; "done" -> "已完成 · 可做种"; "stopped" -> "已停止"; else -> "发生错误" })
        LinearProgressIndicator(progress = { task.progress.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        Text("${(task.progress * 100).toInt()}% · ${mediaBytes(task.downloaded)} / ${mediaBytes(task.length)} · ${task.peers} 个节点", style = MaterialTheme.typography.bodySmall)
        Text("↓ ${mediaBytes(task.speed)}/s    ↑ ${mediaBytes(task.uploadSpeed)}/s", style = MaterialTheme.typography.bodySmall)
        if (task.error.isNotBlank()) Text(task.error, color = MaterialTheme.colorScheme.error)
        if (task.warning.isNotBlank()) Text(task.warning, style = MaterialTheme.typography.bodySmall)
        FlowRow {
            TextButton({ media.action(if (active) "torrentStop" else "torrentResume", mediaId(task.id)) }, enabled = !media.busy) { Text(if (active) "停止" else "继续") }
            TextButton({ expanded = !expanded }) { Text("文件 (${task.files.size})") }
            TextButton(onRemove, enabled = !media.busy) { Text("移除") }
        }
        if (expanded) task.files.forEach { file ->
            HorizontalDivider()
            Row { Checkbox(file.selected, { checked -> media.action("torrentSelect", buildJsonObject { put("id",task.id); put("index",file.index); put("selected",checked) }) }, enabled = active && !media.busy)
                Column(Modifier.weight(1f)) { Text(file.name, maxLines = 2, overflow = TextOverflow.Ellipsis); Text("${mediaBytes(file.length)} · ${(file.progress * 100).toInt()}%") } }
            FlowRow {
                TextButton({ media.action("torrentSave", buildJsonObject { put("id",task.id); put("index",file.index) }) }, enabled = active && file.progress >= 1 && !media.busy) { Text("保存到本机") }
                if (file.name.substringAfterLast('.').lowercase() in listOf("mp4","webm","ogg","ogv","mp3","m4a","wav")) TextButton({ media.action("torrentPlay", buildJsonObject { put("id",task.id); put("index",file.index) }) }, enabled = active && !media.busy) { Text("播放") }
            }
        }
    } }
}
