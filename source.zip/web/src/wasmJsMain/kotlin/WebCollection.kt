import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import me.him188.ani.app.ui.foundation.AsyncImage
import me.him188.ani.app.ui.manga.TrackingCollectionTabs
import me.him188.ani.app.ui.subject.collection.*

@Composable
fun WebAnimeCollection(session: WebResult, revision: Int, onRefresh: () -> Unit,
    avatar: @Composable (DpSize) -> Unit, onManga: () -> Unit, onLogin: () -> Unit, onOpen: (Int) -> Unit) {
    val pager = rememberPagerState(initialPage = 2) { 5 }
    val scope = rememberCoroutineScope()
    val counts = remember(session.userId, session.signedIn, revision) { mutableStateMapOf<Int, Int>() }
    val loading = remember { mutableStateMapOf<Int, Boolean>() }
    val types = listOf(5, 1, 3, 4, 2)
    val original = LocalWebOriginalTitle.current
    CollectionPageLayout(
        title = { TrackingCollectionTabs(false) { if (it) onManga() } }, settingsIcon = {}, actions = {}, avatar = avatar,
        filters = { CollectionTypeScrollableTabRow(pager.currentPage, { scope.launch { pager.animateScrollToPage(it) } },
            itemLabel = { value -> val index = COLLECTION_TABS_SORTED.indexOf(value); CollectionTypeTabLabel(collectionLabel(types[index], false), counts[types[index]]) }) },
        isRefreshing = { loading[types[pager.currentPage]] == true }, onRefresh = onRefresh,
    ) { _, padding ->
        CollectionPager(pager, Modifier.fillMaxSize()) { page ->
            val type = types[page]
            var offset by rememberSaveable(session.userId, revision) { mutableIntStateOf(0) }
            var items by remember(session.userId, session.signedIn) { mutableStateOf<List<Subject>>(emptyList()) }
            var error by remember(session.userId, session.signedIn) { mutableStateOf<String?>(null) }
            var retry by remember { mutableIntStateOf(0) }
            LaunchedEffect(session.userId, session.signedIn, type, offset, revision, retry) {
                if (!session.signedIn) { items = emptyList(); return@LaunchedEffect }
                loading[type] = true; error = null
                try {
                    val result = request("collection", buildJsonObject { put("username", session.userId); put("type", 2); put("status", type); put("offset", offset) }.toString())
                    items = result.items; counts[type] = result.total
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) { error = e.message }
                finally { loading[type] = false }
            }
            LazyVerticalGrid(GridCells.Adaptive(340.dp), Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        if (!session.signedIn) { Text("登录 Animeko 账号后查看追番收藏"); Button(onLogin) { Text("登录 Animeko") } }
                        if (loading[type] == true) LinearProgressIndicator(Modifier.fillMaxWidth())
                        error?.let { WebError(it, { retry++ }) }
                        if (session.signedIn && loading[type] != true && error == null && items.isEmpty()) Text("这个分类还没有收藏")
                    }
                }
                items(items, key = { it.id }) { subject ->
                    SubjectCollectionCard({ onOpen(subject.id) }, cover = {
                        AsyncImage(subject.cover, subject.title, Modifier.height(148.dp).width(148.dp * 849f / 1200f), contentScale = ContentScale.Crop)
                    }, content = {
                        Column(Modifier.fillMaxSize().padding(12.dp)) {
                            Text(subject.displayTitle(original), style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("已看 ${subject.progress} / ${subject.count.takeIf { it > 0 } ?: "—"} 话", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.weight(1f))
                            TextButton({ onOpen(subject.id) }, Modifier.align(Alignment.End)) { Text("查看详情 / 剧集") }
                        }
                    })
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    if (session.signedIn) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        TextButton({ offset -= 30 }, enabled = offset > 0 && loading[type] != true) { Text("上一页") }
                        TextButton({ offset += 30 }, enabled = offset + 30 < (counts[type] ?: 0) && loading[type] != true) { Text("下一页") }
                    }
                }
            }
        }
    }
}
