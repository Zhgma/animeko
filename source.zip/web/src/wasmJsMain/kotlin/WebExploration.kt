// SPDX-License-Identifier: AGPL-3.0-only
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.material3.carousel.rememberCarouselState
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import kotlin.time.Clock
import kotlin.time.Instant
import me.him188.ani.app.ui.adaptive.AniTopAppBar
import me.him188.ani.app.ui.adaptive.AniTopAppBarDefaults
import me.him188.ani.app.ui.adaptive.NavTitleHeader
import me.him188.ani.app.ui.exploration.trends.TrendingCarouselEntry
import me.him188.ani.app.ui.exploration.trends.TrendingSubjectsCarouselContent
import me.him188.ani.app.ui.exploration.followed.FollowedSubjectItemContent
import me.him188.ani.app.ui.exploration.followed.FollowedSubjectsDefaults
import me.him188.ani.app.ui.exploration.schedule.ScheduleItem
import me.him188.ani.app.ui.exploration.schedule.ScheduleItemDefaults
import me.him188.ani.app.ui.foundation.AsyncImage
import me.him188.ani.app.ui.foundation.avatar.AvatarImage
import me.him188.ani.app.ui.foundation.session.SelfAvatarContent
import me.him188.ani.app.ui.foundation.layout.*
import me.him188.ani.app.ui.foundation.layout.plus as addPadding
import me.him188.ani.app.ui.subject.SubjectGridDefaults
import me.him188.ani.app.ui.subject.SubjectCoverCardContent
import me.him188.ani.app.data.models.preference.NsfwMode
import me.him188.ani.app.ui.lang.*
import me.him188.ani.client.models.AniAiringScheduleForDate
import me.him188.ani.datasources.api.EpisodeSort
import org.jetbrains.compose.resources.stringResource

private data class ExploreLoad(val data: WebResult = WebResult(), val loading: Boolean = true, val error: String? = null)

@Composable
private fun exploreLoad(key: Any?, retry: Int, block: suspend () -> WebResult): ExploreLoad {
    return produceState(ExploreLoad(), key, retry) {
        value = ExploreLoad()
        value = try { ExploreLoad(block(), loading = false) }
        catch (e: CancellationException) { throw e }
        catch (e: Throwable) { ExploreLoad(loading = false, error = e.message ?: "加载失败") }
    }.value
}

@Composable
fun WebBrowse(session: WebResult, onOpen: (Int) -> Unit, onAccount: () -> Unit, onSearch: () -> Unit, onSettings: () -> Unit) {
    var page by rememberSaveable { mutableStateOf("home") }
    if (page == "schedule") { WebExploreSchedule({ page = "home" }, onOpen); return }
    if (page == "trends") { WebTrendingRanking({ page = "home" }, onOpen); return }
    var retryTrends by remember { mutableIntStateOf(0) }
    var retryFollowed by remember { mutableIntStateOf(0) }
    var retryRecommendations by remember { mutableIntStateOf(0) }
    val trends = exploreLoad(Unit, retryTrends) { animekoTrending(0) }
    val followed = exploreLoad(session.userId to session.signedIn, retryFollowed) {
        if (!session.signedIn) WebResult() else animekoCollectionRequest("collection", buildJsonObject { put("status", 3); put("offset", 0) })
    }
    var offset by remember(session.userId) { mutableIntStateOf(0) }
    var recommendations by remember(session.userId) { mutableStateOf<List<Subject>>(emptyList()) }
    val recommendedPage = exploreLoad(session.userId to offset, retryRecommendations) {
        if (session.signedIn) animekoRecommendations(offset) else WebResult()
    }
    LaunchedEffect(recommendedPage) {
        if (!recommendedPage.loading && recommendedPage.error == null)
            recommendations = (if (offset == 0) recommendedPage.data.items else recommendations + recommendedPage.data.items).distinctBy { it.id }
    }
    val window = currentWindowAdaptiveInfo1().windowSizeClass
    val gridParams = SubjectGridDefaults.coverLayoutParameters()
    val followedParams = FollowedSubjectsDefaults.layoutParameters()
    val originalTitle = LocalWebOriginalTitle.current
    val hideNsfw = LocalWebUISettings.current.searchSettings.nsfwMode == NsfwMode.HIDE
    val scroll = if (window.isHeightAtLeastMedium) TopAppBarDefaults.pinnedScrollBehavior() else TopAppBarDefaults.enterAlwaysScrollBehavior()
    Scaffold(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest, topBar = {
        AniTopAppBar(title = { AniTopAppBarDefaults.Title(stringResource(Lang.exploration_title)) },
            actions = { if (!session.signedIn || window.isWidthAtLeastMedium) IconButton(onSettings) { Icon(Icons.Rounded.Settings, "设置") } },
            avatar = { size -> SelfAvatarContent(false, session.signedIn, size, onAccount) { AvatarImage(session.avatar.takeIf { it.isNotBlank() }, it) } },
            searchIconButton = { IconButton(onSearch) { Icon(Icons.Rounded.Search, "搜索") } },
            searchBar = { IconButton(onSearch) { Icon(Icons.Rounded.Search, "搜索") } }, scrollBehavior = scroll)
    }) { padding ->
        LazyVerticalGrid(gridParams.gridCells,
            Modifier.fillMaxSize().wrapContentWidth().widthIn(max = 1300.dp).nestedScroll(scroll.nestedScrollConnection),
            contentPadding = padding.addPadding(PaddingValues(horizontal = window.paneHorizontalPadding, vertical = 8.dp)),
            horizontalArrangement = gridParams.horizontalArrangement, verticalArrangement = gridParams.verticalArrangement) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    NavTitleHeader(title = { Text(stringResource(Lang.exploration_trending), softWrap = false) }, trailingActions = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton({ page = "schedule" }, Modifier.weight(1f, fill = false), contentPadding = ButtonDefaults.ButtonWithIconContentPadding) {
                                Icon(Icons.Rounded.CalendarMonth, null, Modifier.size(ButtonDefaults.IconSize))
                                Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                                Text(stringResource(Lang.exploration_schedule), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            TextButton({ page = "trends" }) {
                                Text(stringResource(Lang.exploration_trending_more), softWrap = false)
                                Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, Modifier.size(ButtonDefaults.IconSize))
                            }
                        }
                    })
                    if (trends.error != null) WebError(trends.error) { retryTrends++ }
                    else if (trends.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
                    else {
                        val values = trends.data.items.filter { !hideNsfw || !it.nsfw }.take(10)
                        val carousel = rememberCarouselState { values.size }
                        TrendingSubjectsCarouselContent(values.size,
                            { index -> values.getOrNull(index)?.let { TrendingCarouselEntry(it.id, it.displayTitle(originalTitle), it.cover) } },
                            { onOpen(it.id) }, contentPadding = PaddingValues(vertical = 8.dp), carouselState = carousel,
                            autoAdvance = { enabled ->
                                LaunchedEffect(carousel, enabled, values.size) {
                                    while (enabled && isActive) {
                                        delay(3000)
                                        if (browserDocumentVisible() && !carousel.isScrollInProgress && values.size > 1) {
                                            @Suppress("INVISIBLE_MEMBER", "INVISIBLE_REFERENCE")
                                            val next = (carousel.pagerState.currentPage + 1) % values.size
                                            carousel.animateScrollToItem(next)
                                        }
                                    }
                                }
                            })
                    }
                    NavTitleHeader(title = { Text(stringResource(Lang.exploration_continue_watching), softWrap = false) })
                    when {
                        !session.signedIn -> TextButton(onAccount) { Text("登录后查看继续观看") }
                        followed.error != null -> WebError(followed.error) { retryFollowed++ }
                        followed.loading -> LinearProgressIndicator(Modifier.fillMaxWidth())
                        followed.data.items.isEmpty() -> Text("将番剧收藏为“在看”后，就会显示在这里", Modifier.padding(vertical = 16.dp))
                        else -> LazyRow(contentPadding = PaddingValues(vertical = 8.dp), horizontalArrangement = followedParams.horizontalArrangement) {
                            items(followed.data.items.filter { !hideNsfw || !it.nsfw }, key = { it.id }) { item ->
                                WebNsfw(item) {
                                    FollowedSubjectItemContent(item.displayTitle(originalTitle), item.cover, false,
                                        { onOpen(item.id) }, { onOpen(item.id) }, followedParams.imageSize, followedParams.shape,
                                        supportingText = { Text("已看 ${item.progress} / ${item.count.takeIf { it > 0 } ?: "—"} 话", maxLines = 1) })
                                }
                            }
                        }
                    }
                    NavTitleHeader(title = { Text(stringResource(Lang.exploration_recommendations), softWrap = false) })
                    if (!session.signedIn) TextButton(onAccount) { Text("登录后查看推荐") }
                }
            }
            items(recommendations, key = { "recommend-${it.id}" }) { item ->
                SubjectCoverCardContent(item.displayTitle(originalTitle), item.cover, false, { onOpen(item.id) },
                    shape = gridParams.cardShape, imageModifier = Modifier.sizeIn(maxWidth = 300.dp, maxHeight = (300f / 9 * 16).dp))
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                when {
                    recommendedPage.error != null -> WebError(recommendedPage.error) { retryRecommendations++ }
                    recommendedPage.loading -> LinearProgressIndicator(Modifier.fillMaxWidth())
                    session.signedIn && recommendations.isEmpty() -> Text("暂无推荐", Modifier.padding(16.dp))
                    recommendedPage.data.items.isNotEmpty() && offset + 30 < recommendedPage.data.total -> {
                        LaunchedEffect(offset, recommendedPage) { offset += 30 }
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}

@Composable
private fun WebTrendingRanking(onBack: () -> Unit, onOpen: (Int) -> Unit) {
    var offset by rememberSaveable { mutableIntStateOf(0) }
    var retry by remember { mutableIntStateOf(0) }
    val data = exploreLoad(offset, retry) { animekoTrending(offset) }
    Scaffold(topBar = { AniTopAppBar(title = { Text("热门排行") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回") } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp)) {
            if (data.loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            data.error?.let { item { WebError(it) { retry++ } } }
            items(data.data.items, key = { it.id }) { item -> WebNsfw(item) { WebSubjectItem(item, onOpen) } }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                TextButton({ offset = (offset - 24).coerceAtLeast(0) }, enabled = offset > 0 && !data.loading) { Text("上一页") }
                TextButton({ offset += 24 }, enabled = offset + 24 < data.data.total && !data.loading) { Text("下一页") }
            } }
        }
    }
}

@Composable
private fun WebExploreSchedule(onBack: () -> Unit, onOpen: (Int) -> Unit) {
    var days by remember { mutableStateOf<List<AniAiringScheduleForDate>>(emptyList()) }
    var selected by rememberSaveable { mutableIntStateOf(0) }
    var retry by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val zone = remember { TimeZone.currentSystemDefault() }
    val originalTitle = LocalWebOriginalTitle.current
    LaunchedEffect(retry) {
        loading = true; error = null
        try { days = animekoSchedule().list; selected = days.indexOfFirst { it.date == Clock.System.now().toLocalDateTime(zone).date.toString() }.coerceAtLeast(0) }
        catch (e: CancellationException) { throw e }
        catch (e: Throwable) { error = e.message }
        finally { loading = false }
    }
    Scaffold(topBar = { AniTopAppBar(title = { Text(stringResource(Lang.exploration_schedule)) }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { WebError(it) { retry++ } }
            if (days.isNotEmpty()) ScrollableTabRow(selected, edgePadding = 16.dp) {
                days.forEachIndexed { index, day -> Tab(selected == index, { selected = index }, text = { Text(day.date) }) }
            }
            LazyColumn(Modifier.fillMaxWidth().weight(1f), contentPadding = PaddingValues(16.dp)) {
                val episodes = days.getOrNull(selected)?.list.orEmpty()
                if (!loading && error == null && episodes.isEmpty()) item { Text("当天没有放送安排", Modifier.padding(16.dp)) }
                items(episodes, key = { "${it.subject.subjectId}-${it.episode.episodeId}" }) { item ->
                    val title = if (originalTitle) item.subject.name else item.subject.nameCn.ifBlank { item.subject.name }
                    ScheduleItem({ onOpen(item.subject.subjectId.toInt()) },
                        subjectTitle = { ScheduleItemDefaults.SubjectTitle(title) },
                        episode = { ScheduleItemDefaults.Episode(EpisodeSort(item.episode.sort), item.episode.ep?.let(::EpisodeSort),
                            if (originalTitle) item.episode.name else item.episode.nameCn.ifBlank { item.episode.name }) },
                        leadingImage = { AsyncImage(item.subject.imageLarge, title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) },
                        time = { ScheduleItemDefaults.Time(if (item.timeKnown == false) null else runCatching { Instant.parse(item.airingTime).toLocalDateTime(zone).time }.getOrNull()) })
                }
            }
        }
    }
}
